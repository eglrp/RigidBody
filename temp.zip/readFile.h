/*
 * readFile.h
 *
 *  Created on: 2013-9-19
 *      Author: FLM
 */

#ifndef READFILE_H
#define READFILE_H
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include "MyShape.h"
using namespace std;
void readFile(vector<MyShape*> &ShapeList) ;

#endif /* READFILE_H*/
